//
//  AppUtility.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 02/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import Foundation
import Alamofire
import ReachabilitySwift

open class AppUtility: NSObject {
    
    static var sharedInstance = AppUtility()
    var reachability: Reachability?
    var isOnline = false
    
    func getHTTPHeaders() -> HTTPHeaders {
        
        //get local timezone offset
        let formatter = DateFormatter()
        formatter.dateFormat = "Z"
        formatter.timeZone = TimeZone.autoupdatingCurrent
        let localTimeZoneOffset = formatter.string(from: Date())
        
        let headers = ["Version": Bundle.main.infoDictionary!["CFBundleVersion"] as! String,"Timezone" : localTimeZoneOffset]
    
        return headers
    }
    
    func dictionaryToJson(_ dictionary:AnyObject){
        
        if JSONSerialization.isValidJSONObject(dictionary) {
            
            do {
                
                let jsonData = try JSONSerialization.data(withJSONObject: dictionary, options: (.prettyPrinted))
                
                print("\(NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String)")
                
            } catch let error as NSError {
                print("ERROR: Unable to serialize json, error: \(error)", terminator: "\n")
                NotificationCenter.default.post(name: Notification.Name(rawValue: "CrashlyticsLogNotification"), object: self, userInfo: ["string": "unable to serialize json, error: \(error)"])
                
                
            }
        } else {
             print("Invalid JSON Object")
        }
    }
}
