//
//  ResponseCollectionSerializable.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 02/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import Foundation
protocol ResponseCollectionSerializable {
    static func collection(from response: HTTPURLResponse, withRepresentation representation: Any) -> [Self]
}

extension ResponseCollectionSerializable where Self: ResponseObjectSerializable {
    static func collection(from response: HTTPURLResponse, withRepresentation representation: Any) -> [Self] {
        var collection: [Self] = []
        
        if let representation = representation as? [[String: Any]] {
            for itemRepresentation in representation {
                if let item = Self(response: response, representation: itemRepresentation as AnyObject) {
                    collection.append(item)
                }
            }
        }
        
        return collection
    }
}
