//
//  StandardError.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 02/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import Foundation
class StandardError: NSObject {
    var Title: String?
    var Message: String?
    var IsHttpError: Bool?
}
