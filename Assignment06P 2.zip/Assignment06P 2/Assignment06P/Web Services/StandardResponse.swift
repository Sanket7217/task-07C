//
//  StandardResponse.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 02/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import Foundation

final class StandardResponse:Serializable, ResponseObjectSerializable{
    
    var success:AnyObject?
    var msg:String?
    var data:AnyObject?
    
    override init() {}
    
    init?(restaurants: [Restaurant]){
        self.success = true as AnyObject
        self.msg = "Restaurants are fetched successfully"
        self.data = ["restaurants" : restaurants] as AnyObject
    }
    
    init?(representation: [String: AnyObject]) {
        self.success = representation["success"]
        self.msg = representation["msg"] as? String
        self.data = representation["data"]
    }
    
    required convenience init?(response: HTTPURLResponse, representation: AnyObject) {
        self.init(representation: representation as! [String: AnyObject])
    }
    
}
