//
//  StandardRequest.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 02/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import Foundation
import Alamofire


open class StandardRequest{
    
    static func AlamofireRequest (_ url: String, method: HTTPMethod = .post, parameters: Parameters? = nil, encoding: ParameterEncoding = JSONEncoding.default, headers:[String: String] = [:], completionHandler: @escaping (_ response:DataResponse<StandardResponse>) -> Void){
        
        var encode: ParameterEncoding = encoding
        
        if method == .get{
            encode = URLEncoding.default
        }
        
        if headers.isEmpty {
            DispatchQueue.global(qos: .background).async {
                //                print("This is run on the background queue")
                let headers = AppUtility.sharedInstance.getHTTPHeaders()
                let _ = Alamofire.request(url, method: method,
                                          parameters: parameters,
                                          encoding: encode,
                                          headers: headers).responseObject(completionHandler: completionHandler)
            }
            
        } else {
            
            let _ = Alamofire.request(url, method: method,
                                      parameters: parameters,
                                      encoding: encode,
                                      headers: headers).responseObject(completionHandler: completionHandler)
        }
    }
    
    static func AlamofireRequestNew (_ url: String, method: HTTPMethod = .post, parameters: Parameters? = nil, encoding: ParameterEncoding = JSONEncoding.default, headers:[String: String] = AppUtility.sharedInstance.getHTTPHeaders(), successHandler: @escaping (StandardResponse?) -> Void , failureHandler: @escaping (StandardError?) -> Void){
        
        var encode: ParameterEncoding = encoding
        
        if method == .get{
            encode = URLEncoding.default
        }
        
        var requestHeader = headers
        
        if requestHeader.isEmpty {
            DispatchQueue.global(qos: .background).async {
                requestHeader = AppUtility.sharedInstance.getHTTPHeaders()
            }
        }
        
        let _ = Alamofire.request(url, method: method,
                                  parameters: parameters,
                                  encoding: encode,
                                  headers: requestHeader).responseObject(completionHandler: {
                                    (response:DataResponse<StandardResponse>) -> Void in
                                    
                                    if (response.response?.statusCode == 200) {
                                        successHandler(response.result.value)
                                    }else{
                                        let standardError = StandardError()
                                        standardError.IsHttpError = true
                                        failureHandler(standardError)
                                    }
                                  })
        
        
    }
    
}
