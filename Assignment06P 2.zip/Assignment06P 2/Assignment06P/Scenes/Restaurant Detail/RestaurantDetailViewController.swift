//
//  RestaurantDetailViewController.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 03/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import UIKit

class RestaurantDetailViewController: BaseViewController {
    
    var restaurant : Restaurant?
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var tvContactNos: UITextView!
    @IBOutlet weak var imvOnlineBooking: UIImageView!
    
    class func instantiateFromStoryboard() -> RestaurantDetailViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: String(describing: self)) as! RestaurantDetailViewController
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setUpWhiteNavigationBar()
        self.title = "Restaurant Details"
        setUpRestaurantDetails()
    }
    
    func setUpRestaurantDetails(){
        
        var address = restaurant?.restaurantAddress ?? ""
        
        if let city = restaurant?.restaurantCity {
            address += " " + city
        }
        
        if let state = restaurant?.restaurantState {
            address += " " + state
        }
        
        if let postCode = restaurant?.restaurantPostcode {
            address += " " + postCode
        }
        
        var contactNos = ""
        
        if let contacts = restaurant?.restaurantContactNumbers {
            for contact in contacts {
                contactNos += contactNos.isEmpty ? ("+61" + contact) : (",+61" + contact)
            }
        }
        
        lblName.text = restaurant?.restaurantName ?? "-"
        lblAddress.text = address
        tvContactNos.text = contactNos
        imvOnlineBooking.image = UIImage(named: restaurant?.onlineBookingAllowed ?? false ? "yes" : "no")
    }
}
