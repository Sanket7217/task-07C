//
//  AddRestaurantViewController.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 11/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import UIKit

class AddRestaurantViewController: BaseViewController {
    
    var restaurantListHandler : RestaurantListHandler?
    var updateRestaurantListDelegate : UpdateRestaurantListDelegate?
    var restaurants : [Restaurant] = []
    let ACCEPTABLE_NUMBERS = "0123456789"
    
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfAddress: UITextField!
    @IBOutlet weak var tfCity: UITextField!
    @IBOutlet weak var tfState: UITextField!
    @IBOutlet weak var tfCN1: UITextField!
    @IBOutlet weak var tfCN2: UITextField!
    @IBOutlet weak var swBookingAllowed: UISwitch!
    @IBOutlet weak var btnAdd: UIButton!
    
    class func instantiateFromStoryboard() -> AddRestaurantViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: String(describing: self)) as! AddRestaurantViewController
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        restaurantListHandler = RestaurantListHandler()
        restaurantListHandler?.restaurantListDelegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.btnAdd.backgroundColor = UIColor.blue
        self.tfCN1.delegate = self
        self.tfCN2.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setUpWhiteNavigationBar()
        self.title = "Add a Restaurant"
    }
    
    @IBAction func clickedAdd(_ sender: UIButton) {
        print("button clicked")
        
        let name: String = tfName.text ?? ""
        let address: String = tfAddress.text ?? ""
        let city: String = tfCity.text ?? ""
        let state: String = tfState.text ?? ""
        let cn1: String = tfCN1.text ?? ""
        let cn2: String = tfCN2.text ?? ""
        let isBookingAllowed: Bool = swBookingAllowed.isOn
        
        if name.isEmpty {
            showToast(message: "Please enter a valid Name")
            return
        }
        
        if address.isEmpty {
            showToast(message: "Please enter a valid Address")
            return
        }
        
        if city.isEmpty {
            showToast(message: "Please enter a valid City")
            return
        }
        
        if state.isEmpty {
            showToast(message: "Please enter a valid State")
            return
        }
        
        if cn1.isEmpty || cn1.count != 9 {
            showToast(message: "Please enter a valid Contact No 1")
            return
        }
        
        if !cn2.isEmpty && cn2.count != 9 {
            showToast(message: "Please enter a valid Contact No 2")
            return
        }
        
        let restaurant = Restaurant()
        restaurant.restaurantName = name
        restaurant.restaurantAddress = address
        restaurant.restaurantCity = city
        restaurant.restaurantState = state
        restaurant.restaurantPostcode = ""
        restaurant.onlineBookingAllowed = isBookingAllowed
        
        var contactNos : [String] = []
        contactNos.append(cn1)
        
        if !cn2.isEmpty {
            contactNos.append(cn2)
        }
        restaurant.restaurantContactNumbers = contactNos
        restaurants.append(restaurant)
        restaurantListHandler?.updateRestaurants(updatedRestaurants: restaurants, isDeleting : false)
    }
}

extension AddRestaurantViewController : RestaurantListDelegate {
    
    func displayLoader(message : String?) {
        super.showIndicator(message ?? "")
    }
    
    func hideLoader() {
        super.hideIndicator()
    }
    
    func displayError(message : String?, shouldCloseApp: Bool?) {
        showToast(message: message ?? "")
    }
    
    func restaurantFetched(restaurants: [Restaurant]) {
        self.restaurants = restaurants
        updateRestaurantListDelegate?.updateRestaurants(restaurants: self.restaurants)
        self.navigationController?.popViewController(animated: true)
    }
}

extension AddRestaurantViewController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        guard let text = textField.text else { return true }
        
        let inverseSet = CharacterSet(charactersIn:ACCEPTABLE_NUMBERS).inverted
        let components = string.components(separatedBy: inverseSet)
        let filtered = components.joined(separator: "")
        
        let newLength = text.count + string.count - range.length
        return newLength <= 9
    }
}
