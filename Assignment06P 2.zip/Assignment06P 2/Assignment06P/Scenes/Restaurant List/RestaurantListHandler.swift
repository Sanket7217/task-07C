//
//  RestaurantListHandler.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 03/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import Foundation
import Alamofire

protocol RestaurantListHandlerInput {
    func fetchRestaurantList()
    func deleteRestaurant(restaurants : [Restaurant], index: Int)
    var restaurantListDelegate : RestaurantListDelegate? {get set}
}

protocol RestaurantListDelegate {
    func displayLoader(message : String?)
    func hideLoader()
    func displayError(message: String?, shouldCloseApp: Bool?)
    func restaurantFetched(restaurants : [Restaurant])
}

protocol UpdateRestaurantListDelegate {
    func updateRestaurants(restaurants : [Restaurant])
}

class RestaurantListHandler: RestaurantListHandlerInput {
    
    var restaurantListDelegate: RestaurantListDelegate?

    internal var isAPIrunning = false;
    func downloadCarDetails() {
        
        let url = "https://api.myjson.com/bins/93b5o"
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            var documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            documentsURL.appendPathComponent("Car.json")
            return (documentsURL, [.removePreviousFile])
        }
        
        Alamofire.download(url, to: destination).responseData { response in
            if let destinationUrl = response.destinationURL {
                print("destinationUrl \(destinationUrl.absoluteURL)")
            }
        }
        
    }
    func fetchRestaurantList() {
        if(!isAPIrunning){
            isAPIrunning = true
            restaurantListDelegate?.displayLoader(message: "fetching restaurants...")
            StandardRequest.AlamofireRequest("https://api.myjson.com/bins/93b5o",method: .get, parameters: nil) { (response:DataResponse<StandardResponse>) -> Void in
                self.isAPIrunning = false
                self.restaurantListDelegate?.hideLoader()
                if (response.result.error != nil) {
                    print("ERROR \(response.result.error!.localizedDescription) ")
                    self.restaurantListDelegate?.displayError(message: "Opps. Something went wrong! Please check your internet connectivity and reopen the app for try again", shouldCloseApp: true)
                } else if(response.response?.statusCode == 200 && response.result.error == nil) {
                    if let data = response.result.value?.data as? [String : AnyObject] {
                        
                        let restaurants = Restaurant.toArray(data["restaurants"] as AnyObject)
                        self.restaurantListDelegate?.restaurantFetched(restaurants: restaurants)
                    } else {
                        self.restaurantListDelegate?.displayError(message: "Opps. Something went wrong! Please check your internet connectivity and reopen the app for try again", shouldCloseApp : true)
                    }
                }else if(response.response?.statusCode != 200 && response.result.error == nil) {
                    print("SHOW ERROR MESSAGE FROM SERVER ", response.response?.statusCode ?? "Response NULL")
                    self.restaurantListDelegate?.displayError(message: "Opps. Something went wrong! Please check your internet connectivity and try again",shouldCloseApp: true)
                }
            }
        }
    }
    
    func updateRestaurants(updatedRestaurants: [Restaurant], isDeleting : Bool?) {
        var restaurants : [[String:Any]] = []
        
        for restaurant in updatedRestaurants {
            let restaurantObj : [String : Any] = [
                "restaurantName" : restaurant.restaurantName ?? "",
                "restaurantContactNumbers" : restaurant.restaurantContactNumbers as Any,
                "restaurantAddress" : restaurant.restaurantAddress as Any,
                "restaurantCity" : restaurant.restaurantCity as Any,
                "restaurantState" : restaurant.restaurantState as Any,
                "restaurantPostcode" : restaurant.restaurantPostcode as Any,
                "onlineBookingAllowed" : restaurant.onlineBookingAllowed as Any
            ]
            
            restaurants.append(restaurantObj)
        }
        
        let data : [String: Any] = ["restaurants" : restaurants]
        
        let parameters:[String: Any] = ["success": true,
                                        "msg" : "Restaurants are fetched successfully",
                                        "data" : data]
        
        AppUtility.sharedInstance.dictionaryToJson(parameters as AnyObject)
        
        
        restaurantListDelegate?.displayLoader(message: isDeleting ?? false ? "deleting..." : "adding...")
        
        StandardRequest.AlamofireRequest("https://api.myjson.com/bins/93b5o",method: .put, parameters: parameters) { (response:DataResponse<StandardResponse>) -> Void in
            
            self.restaurantListDelegate?.hideLoader()
            if (response.result.error != nil) {
                print("ERROR \(response.result.error!.localizedDescription) ")
                self.restaurantListDelegate?.displayError(message: "Opps. Something went wrong! Please check your internet connectivity and try again",shouldCloseApp: false)
            } else if(response.response?.statusCode == 200 && response.result.error == nil) {
                
                self.restaurantListDelegate?.restaurantFetched(restaurants: updatedRestaurants)
                self.restaurantListDelegate?.displayError(message: (isDeleting ?? false) ? "Restaurant is deleted successfully" : "Restaurant is added successfully", shouldCloseApp: false)
                
            }else if(response.response?.statusCode != 200 && response.result.error == nil) {
                print("SHOW ERROR MESSAGE FROM SERVER ", response.response?.statusCode ?? "Response NULL")
                self.restaurantListDelegate?.displayError(message: "Opps. Something went wrong! Please check your internet connectivity and try again", shouldCloseApp: false)
            }
        }
    }
    
    func deleteRestaurant(restaurants : [Restaurant], index: Int) {
        var currentRestaurants = restaurants
        currentRestaurants.remove(at: index)
        updateRestaurants(updatedRestaurants: currentRestaurants,isDeleting: true)
    }
}
