//
//  ViewController.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 02/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.


import UIKit

class ViewController: BaseViewController {
    
    var restaurantListHandler : RestaurantListHandler?
    var restaurants : [Restaurant] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        restaurantListHandler = RestaurantListHandler()
        restaurantListHandler?.restaurantListDelegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
         tableView.rowHeight = 44.0
        tableView.rowHeight = UITableView.automaticDimension
    }

    override func viewWillAppear(_ animated: Bool) {
        self.setUpWhiteNavigationBar()
        self.navigationItem.leftBarButtonItem = nil
        setTitle()
        if restaurants.isEmpty {
            restaurantListHandler?.fetchRestaurantList()
        }
    }
    
    func addRightBarButton(){
        let addBarButtonItem = UIBarButtonItem(title: "Add", style: .plain, target: self, action: #selector(clickedAdd))
        self.navigationItem.rightBarButtonItem  = addBarButtonItem
    }
    
    func setTitle(){
        var title = "Restaurants"
        if restaurants.count > 0  {
            title += " (" + String.init(restaurants.count) + ")"
            addRightBarButton()
        }
        self.title = title
    }
    
    @objc func clickedAdd(){
        print("clickedAdd")
        let addRestaurantViewController = AddRestaurantViewController.instantiateFromStoryboard()
        
        addRestaurantViewController.restaurants = self.restaurants
        addRestaurantViewController.updateRestaurantListDelegate = self
        self.navigationController?.pushViewController(addRestaurantViewController, animated: true)
    }
}

extension ViewController : UITableViewDataSource, UITableViewDelegate {
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurants.count
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let restaurant = restaurants[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "RestaurantTableViewCell") as! RestaurantTableViewCell
        
        cell.lblRestaurantName.text = restaurant.restaurantName ?? "N/A"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete {
            let currentRestaurants = restaurants
            restaurantListHandler?.deleteRestaurant(restaurants: currentRestaurants, index : indexPath.row)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        let restaurant = restaurants[indexPath.row]
        
        let restaurantDetailViewController = RestaurantDetailViewController.instantiateFromStoryboard()
        
        restaurantDetailViewController.restaurant = restaurant
        self.navigationController?.pushViewController(restaurantDetailViewController, animated: true)
    }
}

extension ViewController : RestaurantListDelegate {
    
    func displayLoader(message : String?) {
        super.showIndicator(message ?? "")
    }
    
    func hideLoader() {
        super.hideIndicator()
    }
    
    func displayError(message : String?, shouldCloseApp: Bool?) {
        showToast(message: message ?? "")
        if shouldCloseApp ?? false {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { // Change `2.0` to the desired number of seconds.
                exit(0)
            }
        }
    }
    
    func restaurantFetched(restaurants: [Restaurant]) {
        self.restaurants = restaurants
        setTitle()
        tableView.reloadData()
    }
}

extension ViewController : UpdateRestaurantListDelegate {
    func updateRestaurants(restaurants: [Restaurant]) {
        restaurantFetched(restaurants: restaurants)
    }
}
