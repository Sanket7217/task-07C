//
//  Restaurant.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 03/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import Foundation

final class Restaurant:Serializable, ResponseObjectSerializable{
    
    var restaurantName:String?
    var restaurantContactNumbers:[String]?
    var restaurantAddress:String?
    var restaurantCity : String? //TO-DO Mapping may go wrong for address
    var restaurantState: String?
    var restaurantPostcode: String?
    var onlineBookingAllowed: Bool?
    
    override init() {}
    
    required convenience init?(response: HTTPURLResponse, representation: AnyObject) {
    
        self.init(representation: representation as! [String : AnyObject])
    }
    
    // MARK: NSCoding
//    required convenience init?(coder decoder: NSCoder) {
//        self.init(decoder: decoder)
//    }
    
    init?(representation: [String: AnyObject]) {
        self.restaurantName = representation["restaurantName"] as? String
        self.restaurantContactNumbers = representation["restaurantContactNumbers"] as? [String]
        self.restaurantAddress = representation["restaurantAddress"] as? String
        self.restaurantCity = representation["restaurantCity"] as? String
        self.restaurantState = representation["restaurantState"] as? String
        self.restaurantPostcode = representation["restaurantPostcode"] as? String
        self.onlineBookingAllowed = representation["onlineBookingAllowed"] as? Bool
    }
    
//    init?(decoder: AnyObject) {
//        self.restaurantName = decoder.decodeObject(forKey: "restaurantName") as? String
//        self.restaurantContactNumbers = decoder.decodeObject(forKey: "restaurantContactNumbers") as? [String]
//        self.restaurantAddress = decoder.decodeObject(forKey: "restaurantAddress") as? String
//        self.restaurantCity = decoder.decodeObject(forKey: "restaurantCity") as? String
//        self.restaurantState = decoder.decodeObject(forKey: "restaurantState") as? String
//        self.restaurantPostcode = decoder.decodeObject(forKey: "restaurantPostcode") as? String
//        self.onlineBookingAllowed = decoder.decodeObject(forKey: "onlineBookingAllowed") as? Bool
//    }
//
//    func encode(with coder: NSCoder) {
//        coder.encode(self.restaurantName, forKey: "restaurantName")
//        coder.encode(self.restaurantContactNumbers, forKey: "restaurantContactNumbers")
//        coder.encode(self.restaurantAddress, forKey: "restaurantAddress")
//        coder.encode(self.restaurantCity, forKey: "restaurantCity")
//        coder.encode(self.restaurantState, forKey: "restaurantState")
//        coder.encode(self.restaurantPostcode, forKey: "restaurantPostcode")
//        coder.encode(self.onlineBookingAllowed, forKey: "onlineBookingAllowed")
//    }
    
    static func toArray(_ representation: AnyObject) -> [Restaurant] {
        var restaurants: [Restaurant] = []
        if let representation = representation as? [[String: AnyObject]] {
            for restaurantRepresentation in representation {
                if let restaurant = Restaurant(representation: restaurantRepresentation) {
                    restaurants.append(restaurant)
                }
            }
        }
        return restaurants
    }
}
