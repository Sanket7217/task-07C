//
//  BaseViewController.swift
//  Assignment06P
//
//  Created by Sanket Prajapati on 03/05/19.
//  Copyright © 2019 Sanket Prajapati. All rights reserved.
//

import UIKit
import UIKit
import Alamofire
import MBProgressHUD
import Photos
import ReachabilitySwift
import UserNotifications
import StoreKit

class BaseViewController: UIViewController {
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    let defaults = UserDefaults.standard
    var reachability: Reachability?
    var progressHUD: MBProgressHUD?
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: ReachabilityChangedNotification, object: reachability)
    }
    
    //MARK :- Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let reachability =  AppUtility.sharedInstance.reachability{
            self.reachability = reachability
            NotificationCenter.default.removeObserver(self, name: ReachabilityChangedNotification, object: reachability)
            NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(_:)),name: ReachabilityChangedNotification , object: self.reachability)
        } else{
            self.registerReachability()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.checkConnection()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    //MARK: Reachability
    func registerReachability() {
        
        self.reachability = Reachability()
        AppUtility.sharedInstance.reachability = self.reachability
        
        NotificationCenter.default.removeObserver(self, name: ReachabilityChangedNotification, object: reachability)
        NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(_:)),name: ReachabilityChangedNotification , object: self.reachability)
        do{
            try reachability?.startNotifier()
        }catch{
            print("could not start reachability notifier")
        }
    }
    
    @objc func reachabilityChanged(_ note: Notification) {
        
        let reachability = note.object as! Reachability
        print(reachability.currentReachabilityStatus.description)
        //isOnline check is made to prevent running the  code multiple times
        
        if reachability.isReachable && !AppUtility.sharedInstance.isOnline {
            DispatchQueue.main.async {
                AppUtility.sharedInstance.isOnline = true
                
            }
        } else {
            AppUtility.sharedInstance.isOnline = false
            if !reachability.isReachable {
                DispatchQueue.main.async {
                    
                }
            }
            print("Network not reachable")
        }
    }
    
    func appCameToForeground() {
        
    }
    
    func checkConnection() {
        
    }

    //MARK:- Indicators
    func showIndicator(_ message: String, showProgress: Bool = false){
        progressHUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        if showProgress {
            progressHUD?.animationType = .zoom
//            progressHUD?.contentColor = Color.darkText.value
            progressHUD?.mode = MBProgressHUDMode.annularDeterminate
            progressHUD?.progress = 0.02
        }else {
            progressHUD?.mode = MBProgressHUDMode.indeterminate
        }
        if message != "" {
            progressHUD?.label.text = message
        }
    }
    
    func updateProgressForIndicator(progress : Double) {
        progressHUD?.progress = Float(progress)
    }
    
    func hideIndicator(){
        MBProgressHUD.hide(for: self.view, animated: true)
    }
    
    func closeApp(_ sender : AnyObject) {
        
    }
    
    @IBAction func clickedBack(_ sender: UIButton) {
        
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func clickedClose(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    func hideViews() {
        for subview in view.subviews {
            subview.isHidden = true
        }
    }
    
    func hideViews(except: [Int]) {
        for subview in view.subviews {
            if !except.contains(subview.tag) {
                subview.isHidden = true
            }
        }
    }
    
    func unhideViews() {
        for subview in view.subviews {
            subview.isHidden = false
        }
    }
    
    func showToast(message : String) {

        let toastContainer = UIView(frame: CGRect())
        toastContainer.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastContainer.alpha = 0.0
        toastContainer.layer.cornerRadius = 25;
        toastContainer.clipsToBounds  =  true
        
        let toastLabel = UILabel(frame: CGRect())
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.font.withSize(12.0)
        toastLabel.text = message
        toastLabel.clipsToBounds  =  true
        toastLabel.numberOfLines = 0
        
        toastContainer.addSubview(toastLabel)
        self.view.addSubview(toastContainer)
        
        toastLabel.translatesAutoresizingMaskIntoConstraints = false
        toastContainer.translatesAutoresizingMaskIntoConstraints = false
        
        let a1 = NSLayoutConstraint(item: toastLabel, attribute: .leading, relatedBy: .equal, toItem: toastContainer, attribute: .leading, multiplier: 1, constant: 15)
        let a2 = NSLayoutConstraint(item: toastLabel, attribute: .trailing, relatedBy: .equal, toItem: toastContainer, attribute: .trailing, multiplier: 1, constant: -15)
        let a3 = NSLayoutConstraint(item: toastLabel, attribute: .bottom, relatedBy: .equal, toItem: toastContainer, attribute: .bottom, multiplier: 1, constant: -15)
        let a4 = NSLayoutConstraint(item: toastLabel, attribute: .top, relatedBy: .equal, toItem: toastContainer, attribute: .top, multiplier: 1, constant: 15)
        toastContainer.addConstraints([a1, a2, a3, a4])
        
        let c1 = NSLayoutConstraint(item: toastContainer, attribute: .leading, relatedBy: .equal, toItem: self.view, attribute: .leading, multiplier: 1, constant: 65)
        let c2 = NSLayoutConstraint(item: toastContainer, attribute: .trailing, relatedBy: .equal, toItem: self.view, attribute: .trailing, multiplier: 1, constant: -65)
        let c3 = NSLayoutConstraint(item: toastContainer, attribute: .bottom, relatedBy: .equal, toItem: self.view, attribute: .bottom, multiplier: 1, constant: -75)
        self.view.addConstraints([c1, c2, c3])
        
        UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseIn, animations: {
            toastContainer.alpha = 1.0
        }, completion: { _ in
            UIView.animate(withDuration: 0.5, delay: 1.5, options: .curveEaseOut, animations: {
                toastContainer.alpha = 0.0
            }, completion: {_ in
                toastContainer.removeFromSuperview()
            })
        })
    }
}


extension UIViewController: UINavigationControllerDelegate {
    
    func setupHiddenNavigationBar() {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        self.navigationController?.delegate = self
        UIApplication.shared.statusBarStyle = .default
        self.navigationController?.interactivePopGestureRecognizer!.delegate = nil
    }
    
    func setUpWhiteNavigationBar(){
        
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.delegate = self
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.barTintColor = UIColor.white
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.tintColor = UIColor.black
        UIApplication.shared.statusBarStyle = .default
        let shadowImage = UIImage(named: "navbar_shadow")
        self.navigationController?.interactivePopGestureRecognizer!.delegate = nil
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "back-arrow") , style: UIBarButtonItem.Style.plain, target: self, action: #selector(UIViewController.clickedBack))
        
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.foregroundColor: UIColor.black]
        self.navigationController?.navigationBar.shadowImage = shadowImage
    }
    
    @objc func clickedBack() {
        _ = self.navigationController?.popViewController(animated: true)
    }
}

extension UIColor {
    var hex: String {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        
        self.getRed(&r, green: &g, blue: &b, alpha: &a)
        
        let rInt = Int(r * 255) << 24
        let gInt = Int(g * 255) << 16
        let bInt = Int(b * 255) << 8
        let aInt = Int(a * 255)
        
        let rgba = rInt | gInt | bInt | aInt
        
        return String(format:"#%08x", rgba)
    }
    
    var shortHex: String {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        
        self.getRed(&r, green: &g, blue: &b, alpha: &a)
        
        return String(
            format: "#%02x%02x%02x",
            Int(r * 0xff),
            Int(g * 0xff),
            Int(b * 0xff)
        )
    }
    
}
